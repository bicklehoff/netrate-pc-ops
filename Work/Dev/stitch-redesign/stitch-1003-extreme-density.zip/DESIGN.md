# Design System Document: The Precision Curator

## 1. Overview & Creative North Star
The North Star for this design system is **"The Precision Curator."** 

In the high-stakes world of CRM and financial data, "clean" is the baseline, but "intentional" is the premium differentiator. This system moves away from the rigid, boxed-in layouts of traditional enterprise software. Instead, it utilizes **Editorial Asymmetry** and **Tonal Depth** to guide the eye. By leveraging large-scale typography against a neutral, layered background, we transform raw data into a curated narrative. We treat every data point not as a cell in a table, but as a piece of intelligence resting on a sophisticated, physical landscape.

## 2. Colors
Our palette is anchored by high-authority blues and specialized teals, supported by a "Cool Slate" neutral scale that provides depth without visual noise.

*   **Primary (`#005ac0`):** Used for primary actions and key brand moments. Use `primary_container` (`#0e72ed`) for subtle gradients that add "soul" to CTA buttons.
*   **Secondary (`#006a62`):** Our "Trust Teal," used for success states and financial health indicators (e.g., 'Funded' badges).
*   **Tertiary (`#006c40`):** Reserved for deep-focus accents and specialized data categories.
*   **Neutral Scale:** From `surface` (`#f8fafb`) to `surface_container_highest` (`#e1e3e4`).

### The "No-Line" Rule
To achieve a high-end editorial feel, **1px solid borders are strictly prohibited for sectioning.** We define boundaries through background color shifts. For instance, a list of loan applications should sit on a `surface_container_low` background, while the individual application detail panel slides in on a `surface_container_lowest` (white) layer.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked sheets of fine paper. 
*   **Level 0:** `surface` (The canvas)
*   **Level 1:** `surface_container_low` (Section backgrounds)
*   **Level 2:** `surface_container_lowest` (Cards and actionable floating elements)

### The "Glass & Gradient" Rule
For floating mobile elements (like a sticky "New Lead" FAB or a global search bar), use semi-transparent versions of `surface` with a **20px backdrop-blur**. Apply a subtle linear gradient from `primary` to `primary_container` on main action buttons to move beyond "flat" design.

## 3. Typography
We utilize a dual-font strategy to balance character with clinical readability.

*   **Display & Headlines (Manrope):** A modern sans-serif with geometric foundations. Used for `display-lg` (3.5rem) down to `headline-sm` (1.5rem). The wide apertures of Manrope convey openness and transparency—essential for a CRM.
*   **Body & Titles (Inter):** The industry standard for data legibility. Inter is used for all functional text, ensuring that complex loan numbers and names remain crisp at `body-sm` (0.75rem).
*   **Hierarchy as Identity:** Use high contrast between `headline-lg` and `body-md`. Lead with a large, bold headline for names or amounts, followed immediately by small, low-contrast `label-md` text for metadata (e.g., "Loan #1179").

## 4. Elevation & Depth
We convey importance through **Tonal Layering** rather than structural lines.

*   **The Layering Principle:** Instead of a shadow, place a `surface_container_lowest` card on top of a `surface_container_low` background. The subtle 2-3% shift in brightness creates a sophisticated, "quiet" lift.
*   **Ambient Shadows:** Use only for critical floating elements (Modals/Popovers). Shadows must be diffused: `box-shadow: 0 12px 32px rgba(25, 28, 29, 0.06);`. The shadow color is a tinted version of `on_surface`, never pure black.
*   **The "Ghost Border" Fallback:** If a container must sit on an identical color background, use a 1px border of `outline_variant` (`#c1c6d6`) at **15% opacity**. It should be felt, not seen.
*   **Glassmorphism:** Use for mobile navigation bars and top headers. This allows the vibrant status badges (Teal/Blue) to bleed through the UI as the user scrolls, maintaining a sense of place.

## 5. Components

### Badges & Status Indicators
Status is the pulse of a CRM. 
*   **'Funded':** `secondary_container` background with `on_secondary_container` text.
*   **'Applied':** `primary_fixed` background with `on_primary_fixed_variant` text.
*   **'Prospect':** `surface_variant` background with `on_surface_variant` text.
*   **Style:** Pill-shaped (`rounded-full`), `label-md` typography, uppercase tracking +5%.

### Buttons
*   **Primary:** Gradient from `primary` to `primary_container`. White text. `xl` (0.75rem) corner radius.
*   **Secondary:** Ghost style. No background, `outline_variant` ghost border (20% opacity), `primary` text.

### Cards & Lists
*   **Constraint:** No dividers. 
*   **Execution:** Use `spacing-5` (1.1rem) to separate list items. Use a `surface_container_low` background on hover or active states to indicate interactivity.

### Data Inputs
*   **Text Fields:** `surface_container_highest` background, no border. On focus, a 2px `primary` underline or a subtle ghost border is permitted. Labels should use `label-sm` and sit above the field, never inside.

### Action Chips
Use for filters (e.g., "Active," "Settled"). When active, use `secondary` with `on_secondary`. When inactive, use `surface_container_high` with `on_surface_variant`.

## 6. Do's and Don'ts

### Do
*   **Do** use white space as a structural element. If the data feels cramped, increase your spacing tokens rather than adding lines.
*   **Do** use `manrope` for large currency amounts to give them a "premium" feel.
*   **Do** nest containers to show parent-child relationships (e.g., a borrower's contact info inside a loan file).

### Don't
*   **Don't** use high-contrast black text on white backgrounds. Always use `on_surface` (`#191c1d`) for a softer, more high-end reading experience.
*   **Don't** use sharp corners. Every element should follow the `rounded-md` or `rounded-xl` scale to feel approachable and modern.
*   **Don't** use standard "drop shadows" on cards. Rely on background color shifts first.